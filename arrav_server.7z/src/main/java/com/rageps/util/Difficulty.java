package com.rageps.util;

public enum Difficulty {
	EASY, MEDIUM, HARD
}