package com.rageps.util.rand;

public class InclusiveRandom {

	public final int minimum;

	public final int maximum;

	public InclusiveRandom(int minimum, int maximum) {
		this.minimum = minimum;
		this.maximum = maximum;
	}
}