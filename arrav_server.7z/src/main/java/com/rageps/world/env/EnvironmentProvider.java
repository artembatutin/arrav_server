package com.rageps.world.env;

import java.util.function.Supplier;

/**
 * Created by Ryley Kimmel on 12/8/2016.
 */
public interface EnvironmentProvider extends Supplier<Environment> {
}
