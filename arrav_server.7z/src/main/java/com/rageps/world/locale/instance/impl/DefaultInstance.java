package com.rageps.world.locale.instance.impl;
/*

import com.rageps.world.locale.instance.Instance;
import InstancePolicy;
import Entity;
import Player;

public class DefaultInstance extends Instance {

	public DefaultInstance() {
		super();
	};

	public DefaultInstance(String signature) {
		super(signature);
	}

	public DefaultInstance(String signature, InstancePolicy policy) {
		super(signature, policy);
	}

	@Override
	public void onJoin(Player player) {
	}

	@Override
	public void onExit(Player player) {
	}

	@Override
	public void onDeath(Entity entity) {
	}

	@Override
	public void onCreate(Player creator) {
	}

	@Override
	public void onRegionChange(Player entity) {
	}

}
*/