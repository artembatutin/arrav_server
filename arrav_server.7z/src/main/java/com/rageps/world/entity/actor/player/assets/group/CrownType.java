package com.rageps.world.entity.actor.player.assets.group;

/**
 * Created by Jason M on 2017-05-03 at 1:03 AM
 */
public enum CrownType {
	NONE, PLAYER, DONATOR, SPECIAL
	;
}
