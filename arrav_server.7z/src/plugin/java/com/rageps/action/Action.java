package com.rageps.action;

/**
 * A over-simplified event which handles operations such as object, npc, item clicks...
 * @author Artem Batutin
 */
public abstract class Action {

}
